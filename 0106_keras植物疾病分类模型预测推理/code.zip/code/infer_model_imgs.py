# -*- coding: utf-8 -*-
"""
    keras分类模型预测推理
env:

fun:

ref:

"""
from __future__ import print_function
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import time
import shutil
import numpy as np
import pandas as pd
import keras
from keras.preprocessing import image
name_dict = {
            "0"  :  ["apple healthy0","苹果健康"],
            "1"  :  ["apple disease1","苹果黑星病一般"],
            "2"  :  ["apple disease2","苹果黑星病严重"],
            "3"  :  ["apple disease3","苹果灰斑病"],
            "4"  :  ["apple disease4","苹果雪松锈病一般"],
            "5"  :  ["apple disease5","苹果雪松锈病严重"],

            "6"  :  ["cherry healthy0","樱桃健康"],
            "7"  :  ["cherry disease1","樱桃白粉病一般"],
            "8"  :  ["cherry disease2","樱桃白粉病严重"],

            "9"  :  ["corn healthy0","玉米健康"],
            "10" :  ["corn disease1","玉米灰斑病一般"],
            "11" :  ["corn disease2","玉米灰斑病严重"],
            "12" :  ["corn disease3","玉米锈病一般"],
            "13" :  ["corn disease4","玉米锈病严重"],
            "14" :  ["corn disease5","玉米叶斑病一般"],
            "15" :  ["corn disease6","玉米叶斑病严重"],
            "16" :  ["corn disease7","玉米花叶病毒病"],

            "17" :  ["grape healthy0","葡萄健康"],
            "18" :  ["grape disease1","葡萄黑腐病一般"],
            "19" :  ["grape disease2","葡萄黑腐病严重"],
            "20" :  ["grape disease3","葡萄轮斑病一般"],
            "21" :  ["grape disease4","葡萄轮斑病严重"],
            "22" :  ["grape disease5","葡萄褐斑病一般"],
            "23" :  ["grape disease6","葡萄褐斑病严重"],

            "24" :  ["citrus healthy0","柑桔健康"],
            "25" :  ["citrus disease1","柑桔黄龙病一般"],
            "26" :  ["citrus disease2","柑桔黄龙病严重"],

            "27" :  ["peach healthy0","桃子健康"],
            "28" :  ["peach disease1","桃子疮痂病一般"],
            "29" :  ["peach ","桃子疮痂病严重"],

            "30" :  ["pepper healthy0","辣椒健康"],
            "31" :  ["pepper disease1","辣椒疮痂病一般"],
            "32" :  ["pepper disease2","辣椒疮痂病严重"],

            "33" :  ["potato healthy0","马铃薯健康"],
            "34" :  ["potato disease1","马铃薯早疫病一般"],
            "35" :  ["potato disease2","马铃薯早疫病严重"],
            "36" :  ["potato disease3","马铃薯晚疫病一般"],
            "37" :  ["potato disease4","马铃薯晚疫病严重"],

            "38" :  ["strawberry healthy0","草莓健康"],
            "39" :  ["strawberry disease1","草莓叶枯病一般"],
            "40" :  ["strawberry disease2","草莓叶枯病严重"],

            "41" :  ["tomato healthy0","番茄健康"],
            "42" :  ["tomato disease1","番茄白粉病一般"],
            "43" :  ["tomato disease2","番茄白粉病严重"],
            "44" :  ["tomato disease3","番茄疮痂病一般"],
            "45" :  ["tomato disease4","番茄疮痂病严重"],
            "46" :  ["tomato disease5","番茄早疫病一般"],
            "47" :  ["tomato disease6","番茄早疫病严重"],
            "48" :  ["tomato disease7","番茄晚疫病一般"],
            "49" :  ["tomato disease8","番茄晚疫病严重"],
            "50" :  ["tomato disease9","番茄叶霉病一般"],
            "51" :  ["tomato disease10","番茄叶霉病严重"],
            "52" :  ["tomato disease11","番茄斑点病一般"],
            "53" :  ["tomato disease12","番茄斑点病严重"],
            "54" :  ["tomato disease13","番茄斑枯病一般"],
            "55" :  ["tomato disease14","番茄斑枯病严重"],
            "56" :  ["tomato disease15","番茄红蜘蛛损伤一般"],
            "57" :  ["tomato disease16","番茄红蜘蛛损伤严重"],
            "58" :  ["tomato disease17","番茄黄化曲叶病毒病一般"],
            "59" :  ["tomato disease18","番茄黄化曲叶病毒病严重"],
            "60" :  ["tomato disease19","番茄花叶病毒病"]
}
class_dict = {'0': 0, '1': 1, '10': 2, '11': 3, '12': 4, '13': 5, '14': 6, '15': 7, '16': 8, '17': 9, '18': 10, '19': 11, '2': 12, '20': 13, '21': 14, '22': 15, '23': 16, '24': 17, '25': 18, '26': 19, '27': 20, '28': 21, '29': 22, '3': 23, '30': 24, '31': 25, '32': 26, '33': 27, '34': 28, '35': 29, '36': 30, '37': 31, '38': 32, '39': 33, '4': 34, '40': 35, '41': 36, '42': 37, '43': 38, '44': 39, '45': 40, '46': 41, '47': 42, '48': 43, '49': 44, '5': 45, '50': 46, '51': 47, '52': 48, '53': 49, '54': 50, '55': 51, '56': 52, '57': 53, '58': 54, '59': 55, '6': 56, '60': 57, '7': 58, '8': 59, '9': 60}

test_dir = "test"
res_dir = "out"
model_path = 'models/model05_Vgg_best.h5'

if os.path.exists(res_dir):
    shutil.rmtree(res_dir)
os.makedirs(res_dir)
# model01_ResNet50_best.h5       model04_Alexnet_best.h5
# model0201_InceptionV3_best.h5  model05_Vgg_best.h5
start_time = time.time()
model = keras.models.load_model(model_path)
end_time = time.time()
len_time = end_time - start_time
print("模型加载用时 : ", round(len_time, 3), "秒")
img_list = []
gt_list = []
pd_list = []
prob_list = []
cnt_img = 0
start_time = time.time()
for img_dir in os.listdir(test_dir) :
    for img_name in os.listdir(os.path.join(test_dir,img_dir)):
        img_path = os.path.join(test_dir,img_dir,img_name)
        img_list.append(img_path)
        gt_list.append(img_dir) # 真值标签通过文件夹名称获得
        img = image.load_img(img_path, target_size=(224, 224))
        img = image.img_to_array(img)/ 255.0
        img = np.expand_dims(img, axis=0)  # 为batch添加第四维
        result = model.predict(img)
        # print("result.shape",result.shape) # (1,num_classes)
        # print("result[0]",result[0])
        cls_prob = round(np.max(result[0]), 3)
        # print("cls_prob",cls_prob)
        prob_list.append(cls_prob)
        cls_index = np.argmax(result[0]) # top1 取最大的一个
        # cls_index = np.argsort(-result[0])[:5] # top5 取前五个 最大的五个数
        # print("cls_index",cls_index)
        cls_label = [k for k,v in class_dict.items() if v==cls_index][0] # 根据值找字典的键
        print("img_path",img_path)
        # print("cls_label",cls_label)
        pd_list.append(cls_label)
        cls_name = [v for k,v in name_dict.items() if k==cls_label][0] # 根据键找字典的值
        # print("cls_name",cls_name)
        cnt_img += 1
end_time = time.time()
len_time = end_time - start_time
print("预测推理总用时 : ", round(len_time, 3), "秒，","共%d张图片，每张图片平均推理用时%.3f秒"%(cnt_img,len_time/cnt_img))
res_dict = {'images': img_list,
        'target': gt_list,
        'predict': pd_list,
        'prob': prob_list,
        }
df_output = pd.DataFrame(res_dict)
results_csv_path = os.path.join(res_dir,"result_"+(time.strftime("Date%m%dTime%H%M"))+".csv")
df_output.to_csv(results_csv_path, index=None, header=1)
