# -*- coding: utf-8 -*-
'''
Author      : now more
Connect     : lin.honghui@qq.com
LastEditors: Please set LastEditors
Description : 
LastEditTime: 2020-11-28 05:43:40
'''
import os
from data.dataloader import make_dataloader
# elesun
from model import build_model
from solver import make_optimizer,wrapper_lr_scheduler
from engine import do_train
import torch.nn as nn
import torch
import copy
import datetime
from configs.deeplabv3plus_resnet101_StepLR_Adam import config as cfg # elesun

# os.environ['CUDA_VISIBLE_DEVICES'] = '1,2,3' # 可见哪些GPU
master_device = 0 # 模型存放GPU编号
mgpu_device_ids = [0,1,2,3] # 多GPU并行序列编号

if __name__ == "__main__":
    print(cfg)
    cfg_copy = copy.deepcopy(cfg)
    train_dataloader = make_dataloader(cfg['train_pipeline'])
    curr_time = datetime.datetime.now()
    time_str = datetime.datetime.strftime(curr_time,'%Y%m%d_')
    save_dir = os.path.join(cfg['save_dir'],time_str+cfg['tag'])
    log_dir = os.path.join(cfg['log_dir'],"log_"+time_str+cfg['tag'])
    cfg['save_dir'] = save_dir
    cfg['log_dir'] = log_dir
    if not os.path.isdir(save_dir):
        os.makedirs(save_dir)
    if not os.path.isdir(log_dir):
        os.makedirs(log_dir)
    print("Save_dir :",save_dir)
    print("Log_dir :", log_dir)
    model = build_model(cfg)
    optimizer = make_optimizer(cfg['optimizer'],model)
    lr_scheduler = wrapper_lr_scheduler(cfg['lr_scheduler'],optimizer)

    model.cuda(master_device) # elesun
    # model = nn.DataParallel(model,device_ids=free_device_ids).cuda(master_device) # elesun
    model = nn.DataParallel(model, device_ids=mgpu_device_ids).cuda(master_device) # elesun

    if cfg['enable_backends_cudnn_benchmark']:
        print("enable backends cudnn benchmark")
        torch.backends.cudnn.benchmark = True

    cfg_copy['save_dir'] = save_dir # 更新存储目录
    cfg_copy['log_dir'] = log_dir # 更新存储目录
    # import pdb; pdb.set_trace()
    do_train(cfg_copy,model=model,train_loader=train_dataloader,val_loader=None,optimizer=optimizer,
                scheduler=lr_scheduler,metrics=None,device=mgpu_device_ids) # elesun