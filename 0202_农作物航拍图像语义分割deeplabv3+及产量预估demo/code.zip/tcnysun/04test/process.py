# -*- coding: utf-8 -*-
'''

'''
import os
from PIL import Image
from tqdm import tqdm
import numpy as np
import pandas as pd
import cv2
Image.MAX_IMAGE_PIXELS = None

def crop_block(image_path, label_path, save_dir):
    save_image_dir = os.path.join(save_dir, "image")
    save_label_dir = os.path.join(save_dir, "label")
    s = 512  # stride
    b = 1024  # block_size
    if not os.path.exists(save_image_dir): os.makedirs(save_image_dir)
    if not os.path.exists(save_label_dir): os.makedirs(save_label_dir)
    root_dir, filename = os.path.split(image_path)
    basename, filetype = os.path.splitext(filename)

    image = np.asarray(Image.open(image_path))
    if label_path is not None:
        label = np.asarray(Image.open(label_path))
    # image = cv.imread(image_path,cv.IMREAD_UNCHANGED)
    # label = cv.imread(label_path,cv.IMREAD_GRAYSCALE)
    cnt = 0
    csv_pos_list = []

    # 填充外边界至步长整数倍,方便整除
    h, w = image.shape[0], image.shape[1]
    # print("raw img ", "hy:", h, "wx:", w)
    new_w = (w // b) * b if (w // b == 0) else (w // b + 1) * b
    new_h = (h // b) * b if (h // b == 0) else (h // b + 1) * b
    image = cv2.copyMakeBorder(image, 0, new_h - h, 0, new_w - w, cv2.BORDER_CONSTANT, 0)

    if label_path is not None:
        label = cv2.copyMakeBorder(label, 0, new_h - h, 0, new_w - w, cv2.BORDER_CONSTANT, 0)

    # 填充1/2 stride长度的外边框
    h, w = image.shape[0], image.shape[1]
    # print("strideN img ", "hy:", h, "wx:", w)
    new_w, new_h = w + s, h + s
    image = cv2.copyMakeBorder(image, s // 2, s // 2, s // 2, s // 2, cv2.BORDER_CONSTANT, 0)
    if label_path is not None:
        label = cv2.copyMakeBorder(label, s // 2, s // 2, s // 2, s // 2, cv2.BORDER_CONSTANT, 0)

    def crop(cnt, crop_image, crop_label):
        image_name = os.path.join(save_image_dir, basename + "_" + str(cnt) + ".png")
        cv2.imwrite(image_name, crop_image)
        if crop_label is not None:
            label_name = os.path.join(save_label_dir, basename + "_" + str(cnt) + ".png")
            cv2.imwrite(label_name, crop_label)

    h, w = image.shape[0], image.shape[1]
    # print("stride+ img ", "hy:", h, "wx:", w)
    print("切割进行中...")
    for col in tqdm(range(w // s - 1)):
        for row in range(h // s - 1):
            x0 = col * s
            y0 = row * s
            crop_image = image[y0:y0 + b, x0:x0 + b]
            crop_label = label[y0:y0 + b, x0:x0 + b] if label_path is not None else None

            if crop_image.shape[:2] != (b, b):
                print(x0, y0, crop_image.shape)

            if np.sum(crop_image) == 0:
                pass
            else:
                crop(cnt, crop_image, crop_label)
                csv_pos_list.append([basename + "_" + str(cnt) + ".png", x0, y0, x0 + b, y0 + b])
                cnt += 1
    csv_pos_list = pd.DataFrame(csv_pos_list)
    csv_pos_list.to_csv(os.path.join(save_dir, basename + ".csv"), header=None, index=None)