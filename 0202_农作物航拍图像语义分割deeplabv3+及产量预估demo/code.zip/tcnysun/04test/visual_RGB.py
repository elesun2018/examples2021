# -*- coding: utf-8 -*-
'''
大图可视化
label标签RGB可视化
https://tianchi.aliyun.com/notebook-ai/detail?spm=5176.12586969.1002.18.25ea4054aaYJei&postId=61355

类别	  像素值	颜色        B     G     R    | 颜色        R     G     B
烤烟	  1	        棕色br     165， 42， 42     | 蓝色        0     0     255
玉米	  2	        黄色ye     255，255， 0      | 绿色        0     255   0
薏仁米	  3	        白色wh     255，255，255     | 红色        255   0     0
建筑      4         灰色gr     190，190，190     | 黄色        255   255   0
其他	  0	        黑色bl     0  ，  0， 0      | 黑色        0     0     0
'''
from collections import Counter
import cv2
from PIL import Image
import numpy as np
Image.MAX_IMAGE_PIXELS = None

# 像素统计 + 可视化
def cal_vis(lab_path, img_path, save_path):
    lab = Image.open(lab_path)
    lab = np.asarray(lab)  # array仍会copy出一个副本，占用新的内存，但asarray不会。
    # lab = cv2.resize(lab, None, fx=0.1, fy=0.1)  # 缩小 0.1 * 0.1
    img = Image.open(img_path)
    img = np.asarray(img)  # array仍会copy出一个副本，占用新的内存，但asarray不会。
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)  # COLOR_RGB2BGR COLOR_RGBA2BGRA opencv需要使用BGR通道顺序
    # img = cv2.resize(img, None, fx=0.1, fy=0.1)  # 缩小 0.1 * 0.1
    assert img.shape[0:2] == lab.shape
    # 像素统计
    rate = 0.035
    print("图像比例尺为：1pix:{}m".format(rate))
    name_list = ["其他", "烤烟", "玉米", "水稻", "建筑"]  # ["other","tobacco","corn","rice","building"]
    color_list = ["黑色", "蓝色", "绿色", "红色",
                  "黄色"]  # ["black","blue","green","red","yellow"] #其中“烤烟”像素值 1，“玉米”像素值 2，“薏仁米”像素值 3，“人造建筑”像素值 4，其余所有位置视为“其他”像素值 0
    coe_list = [1, 3.67, 9.18, 3.67, 1]
    dict = Counter(lab.ravel())
    res_dict = {}
    for key, value in dict.items():
        dict[key] = [name_list[key], color_list[key], value]
    for key, value in dict.items():
        # print(key, ":", value)
        # print(dict[key][0],":",dict[key][2])
        if key == 0 or key == 4: continue  # 其他背景和建筑不同计算
        # print("颜色：{0}；类别：{1}；像素量：{2}pix；种植面积：{3:.2f}㎡；预估产量：{4:.2f}Kg".format(
        #     dict[key][1], dict[key][0], dict[key][2], dict[key][2] * rate * rate, dict[key][2] / 10000 * coe_list[key]))
        # 返回的字典保存 key ：颜色 类别 种植面积 预估产量
        res_dict[key] = [dict[key][1], dict[key][0], round(dict[key][2] * rate * rate,2), round(dict[key][2] / 10000 * coe_list[key],2)]
    # 可视化颜色映射
    # 其他	  0	        黑色bl     0  ，  0，  0
    R = np.zeros(lab.shape, np.int)
    G = np.zeros(lab.shape, np.int)
    B = np.zeros(lab.shape, np.int)
    # 烤烟	    1	      棕色br     165， 42， 42
    R[lab == 1] =   0; G[lab == 1] =   0; B[lab == 1] = 255
    # 玉米      2         黄色ye     255，255， 0
    R[lab == 2] =   0; G[lab == 2] = 255; B[lab == 2] =   0
    # 薏仁米	3	      白色wh     255，255，255
    R[lab == 3] = 255; G[lab == 3] =   0; B[lab == 3] =   0
    # 建筑      4         灰色gr     190，190，190  深灰色 130, 130, 130
    R[lab == 4] = 255; G[lab == 4] = 255; B[lab == 4] =   0

    lab_BGR = np.dstack((B, G, R))  # opencv需要使用BGR通道顺序
    # print("lab_BGR.shape", lab_BGR.shape)
    alpha = 0.5 # 权重透明度
    res_img = cv2.addWeighted(img, alpha, lab_BGR, 1 - alpha, 0, dtype = cv2.CV_32F)
    cv2.imwrite(save_path, res_img,[int(cv2.IMWRITE_JPEG_QUALITY), 100])  # 注意修改 可视化img 的路径
    return res_dict, res_img

if __name__ == "__main__":
    lab_path  = ""  # 注意修改路径
    img_path  = ""  # 注意修改路径
    save_path = ""  # 注意修改路径
    visual(lab_path, img_path, save_path)


