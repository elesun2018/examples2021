# -*- coding: utf-8 -*-
'''

'''
import os,time
os.environ['CUDA_VISIBLE_DEVICES'] = '3'
from lin_dataprocess.dataloader import make_dataloader
from lin_network import build_model
import torch
import torch.nn as nn
import shutil
from PIL import Image
import cv2
from tqdm import tqdm
import numpy as np
from process import crop_block
from metrics_seg import SegmentationMetric
from visual_RGB import cal_vis
Image.MAX_IMAGE_PIXELS = None
torch.backends.cudnn.benchmark = True
import warnings
warnings.filterwarnings("ignore")

def create_zeros_png(image_w,image_h):
    '''Description:
        0. 先创造一个空白图像，将滑窗预测结果逐步填充至空白图像中；
        1. 填充右下边界，使原图大小可以杯滑动窗口整除；
        2. 膨胀预测：预测时，对每个(1024,1024)窗口，每次只保留中心(512,512)区域预测结果，每次滑窗步长为512，使预测结果不交叠；
    '''
    new_h,new_w = (image_h//1024+1)*1024,(image_w//1024+1)*1024 #填充右边界
    zeros = (256+new_h+256,256+new_w+256)  #填充空白边界
    zeros = np.zeros(zeros,np.uint8)
    return zeros

def tta_forward(dataloader,model,png_shape,device=None):
    image_w,image_h = png_shape
    predict_png = create_zeros_png(image_w,image_h)
    model = model.eval()
    # 测试增强
    # 测试时，通过对图像水平翻转，垂直翻转，水平垂直翻转等多次预测，再对预测结果取平均可以提高精度，但相对的，推理时间也会大幅度升高。
    with torch.no_grad():
        print("预测进行中...")
        for (image,pos_list) in tqdm(dataloader):
            # forward --> predict
            image = image.cuda(device) 

            predict_1 = model(image)

            predict_2 = model(torch.flip(image,[-1]))
            predict_2 = torch.flip(predict_2,[-1])

            predict_3 = model(torch.flip(image,[-2]))
            predict_3 = torch.flip(predict_3,[-2])

            predict_4 = model(torch.flip(image,[-1,-2]))
            predict_4 = torch.flip(predict_4,[-1,-2])
            predict_list = predict_1 + predict_2 + predict_3 + predict_4
            predict_list = torch.argmax(predict_list.cpu(),1).byte().numpy() # n x h x w
            batch_size = predict_list.shape[0] # batch大小
            for i in range(batch_size):
                predict = predict_list[i]
                pos = pos_list[i,:]
                [x0,y0,x1,y1] = pos
                if(x1-x0)==1024 and (y1-y0)==1024 :
                    if y1-256 <= predict_png.shape[0] and x1-256 <= predict_png.shape[1] :
                        # 每次预测只保留图像中心(512,512)区域预测结果
                        predict_png[y0+256:y1-256,x0+256:x1-256] = predict[256:768,256:768]
                else:
                    raise ValueError("target_size!=512， Got {},{}".format(x1-x0,y1-y0))

    h,w = predict_png.shape
    predict_png =  predict_png[256:h-256,256:w-256] # 去除整体外边界
    predict_png = predict_png[:image_h,:image_w]    # 去除补全512整数倍时的右下边界
    return predict_png

def interface(img_dec, model_path="model.pth"):
    # 数据路径
    temp_dir = "temp"
    midimg_dir = temp_dir # "../../../results/sun/samples/round2_train"
    midimg_name = "midimg.png" #"img20_w3288_h4464_cnt027.png"
    midlab_name = ""#"lab20_w3288_h4464_cnt027.png"
    cv2.imwrite(os.path.join(temp_dir, midimg_name), img_dec, [int(cv2.IMWRITE_JPEG_QUALITY), 100])
    midimg_path = os.path.join(midimg_dir, midimg_name)
    midlab_path = None # os.path.join(midimg_dir, midlab_name)
    block_dir = os.path.join(temp_dir,"midCrop1024")# "../../../results/sun/samples/midCrop1024"
    save_lab_dir = "predict"
    save_lab_path = os.path.join(save_lab_dir, "lab_pd.png")
    if os.path.exists(save_lab_dir):
        shutil.rmtree(save_lab_dir)
    os.makedirs(save_lab_dir)
    save_vis_dir = "visual"
    save_vis_path = os.path.join(save_vis_dir, "overlap.jpg")
    if os.path.exists(save_vis_dir):
        shutil.rmtree(save_vis_dir)
    os.makedirs(save_vis_dir)
    # 图片切割
    crop_block(midimg_path, midlab_path, block_dir)
    ### 分割后的图片配置
    img = Image.open(midimg_path)
    img = np.asarray(img)  # array仍会copy出一个副本，占用新的内存，但asarray不会。
    # print("img.shape",img.shape)
    image_cfg = dict(
        dataloader=dict(batch_size=12, num_workers=12, drop_last=False, pin_memory=True, shuffle=False),
        dataset=dict(type="Inference_Dataset",
                     csv_file=os.path.join(block_dir, midimg_name.split(".")[0] + ".csv"),
                     # "../../../../../results/lin_tcny/pyCrop1024/image_3.csv"
                     image_dir=os.path.join(block_dir, "image")),  # "../../../../../results/lin_tcny/pyCrop1024/image"
        transforms=[
            dict(type="ToTensor", ),
            dict(type="Normalize", mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225], inplace=True),
        ],
        image_shape=(img.shape[1], img.shape[0]),  # (4464, 3288) (37241, 19903)
    )
    # 网络模型
    net_cfg = dict(
        model=dict(
            net=dict(type="deeplabv3plus", num_classes=5),
            backbone=dict(type="resnet101", pretrained=True, replace_stride_with_dilation=[False, False, 2]),
            head=dict(type="ASPP", in_channels=2048, out_channels=256, dilation_list=[6, 12, 18]),
            loss=dict(type="LabelSmoothing", win_size=11, num_classes=5, ),
        )
    )
    # model_path = 'models/deeplabv3plus_resnet101_StepLR_Adam_temp.pth'
    model = build_model(net_cfg, pretrain_path=model_path)
    model = nn.DataParallel(model).cuda()
    # 进行预测
    start_time = time.time()
    image_pipeline = make_dataloader(image_cfg)
    image_predict = tta_forward(image_pipeline, model, device=0, png_shape=image_cfg['image_shape'])
    pil_image = Image.fromarray(image_predict)
    pil_image.save(save_lab_path)
    del image_pipeline, image_predict
    end_time = time.time()

    # 像素统计并可视化
    res_dict, res_img = cal_vis(save_lab_path, midimg_path, save_vis_path)  # midlab_path
    # for key, value in res_dict.items():
    #     print("res_dict", key, ":", value)
    # 指标计算
    print("预测用时 : ", round((end_time - start_time), 3), "秒")
    if (midlab_path is not None) and os.path.exists(save_lab_path):
        imgPredict = Image.open(save_lab_path)
        imgPredict = np.array(imgPredict)
        imgLabel = Image.open(midlab_path)
        imgLabel = np.array(imgLabel)
        numclass = 5
        metric = SegmentationMetric(numclass)
        metric.addBatch(imgPredict, imgLabel)
        mIoU = metric.meanIntersectionOverUnion()
        print("交并比值 :  %.3f" % mIoU)
    return res_dict, res_img

if __name__ == "__main__":
    # 数据路径
    midimg_dir = "../../../results/sun/samples/round2_train"
    midimg_name = "img20_w3288_h4464_cnt027.png"
    midlab_name = "lab20_w3288_h4464_cnt027.png"
    midimg_path = os.path.join(midimg_dir, midimg_name)
    midlab_path = os.path.join(midimg_dir, midlab_name)
    block_dir = "../../../results/sun/samples/midCrop1024"
    save_lab_dir = "predict"
    save_lab_path = os.path.join(save_lab_dir, "lab_pd.png")
    if os.path.exists(save_lab_dir):
        shutil.rmtree(save_lab_dir)
    os.makedirs(save_lab_dir)
    save_vis_dir = "visual"
    save_vis_path = os.path.join(save_vis_dir, "overlap.png")
    if os.path.exists(save_vis_dir):
        shutil.rmtree(save_vis_dir)
    os.makedirs(save_vis_dir)
    # 图片切割
    crop_block(midimg_path, midlab_path, block_dir)
    ### 分割后的图片配置
    image_cfg = dict(
        dataloader=dict(batch_size=12, num_workers=12, drop_last=False, pin_memory=True, shuffle=False),
        dataset=dict(type="Inference_Dataset",
                     csv_file=os.path.join(block_dir,midimg_name.split(".")[0]+".csv"), # "../../../../../results/lin_tcny/pyCrop1024/image_3.csv"
                     image_dir=os.path.join(block_dir,"image")),# "../../../../../results/lin_tcny/pyCrop1024/image"
        transforms=[
            dict(type="ToTensor", ),
            dict(type="Normalize", mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225], inplace=True),
        ],
        image_shape=(4464, 3288), # (37241, 19903)
    )
    # 网络模型
    net_cfg = dict(
        model=dict(
            net=dict(type="deeplabv3plus", num_classes=5),
            backbone=dict(type="resnet101", pretrained=True, replace_stride_with_dilation=[False, False, 2]),
            head=dict(type="ASPP", in_channels=2048, out_channels=256, dilation_list=[6, 12, 18]),
            loss=dict(type="LabelSmoothing", win_size=11, num_classes=5, ),
        )
    )
    model_path = 'models/deeplabv3plus_resnet101_StepLR_Adam_temp.pth'
    model = build_model(net_cfg, pretrain_path=model_path)
    model = nn.DataParallel(model).cuda()
    #进行预测
    start_time = time.time()
    image_pipeline = make_dataloader(image_cfg)
    image_predict = tta_forward(image_pipeline, model, device=0,png_shape=image_cfg['image_shape'])
    pil_image = Image.fromarray(image_predict)
    pil_image.save(save_lab_path)
    del image_pipeline, image_predict
    end_time = time.time()

    #像素统计并可视化
    res_dict, res_img = cal_vis(midlab_path, midimg_path, save_vis_path)  # midlab_path
    for key, value in res_dict.items():
        print("res_dict",key, ":", value)
    #指标计算
    print("预测用时 : ", round((end_time - start_time), 3), "秒")
    if os.path.exists(midlab_path) and os.path.exists(save_lab_path):
        imgPredict = Image.open(save_lab_path)
        imgPredict = np.array(imgPredict)
        imgLabel = Image.open(midlab_path)
        imgLabel = np.array(imgLabel)
        numclass = 5
        metric = SegmentationMetric(numclass)
        metric.addBatch(imgPredict, imgLabel)
        mIoU = metric.meanIntersectionOverUnion()
        print("交并比值 :  %.3f"% mIoU)

