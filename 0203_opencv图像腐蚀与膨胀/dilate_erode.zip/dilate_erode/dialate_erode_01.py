# -*- coding: utf-8 -*-
'''
图像腐蚀与图像膨胀
腐蚀的作用说白了就是让暗的区域变大，而膨胀的作用就是让亮的区域变大
膨胀就是求局部最大值的操作,膨胀就是求局部最大值的操作。
https://www.jb51.net/article/190280.htm
'''
import cv2
import numpy as np

# 图像腐蚀 白色区域减小，黑色区域增大
img = cv2.imread("erode_source.png",cv2.IMREAD_GRAYSCALE) # 读入灰度图片
k = np.ones((5,5),np.uint8)
# 卷积核kernel：一般为正方形数组
res = cv2.erode(img,k,iterations=2)
# 处理结果=cv2.erode(原始图像src,卷积核kernel,迭代次数iterations)
cv2.imwrite("erode_dest01.png", res)

# 图像膨胀 黑色区域减小，白色区域增大
img = cv2.imread("dilate_source.png",cv2.IMREAD_GRAYSCALE) # 读入灰度图片
k=np.ones((5,5),np.uint8)
# 卷积核 正方形数组
res = cv2.dilate(img,k,iterations=2)
# 结果=cv2.dilate(二值图像src,卷积核k,迭代次数itreations)
cv2.imwrite("dilate_dest01.png", res)
