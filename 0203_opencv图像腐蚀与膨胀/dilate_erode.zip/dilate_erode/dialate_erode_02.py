# -*- coding: utf-8 -*-
'''
图像腐蚀与图像膨胀
腐蚀的作用说白了就是让暗的区域变大，而膨胀的作用就是让亮的区域变大
膨胀就是求局部最大值的操作,膨胀就是求局部最大值的操作。
https://blog.csdn.net/weixin_44237705/article/details/108315455
'''
import cv2
import numpy as np

# 图像腐蚀 白色区域减小，黑色区域增大
img = cv2.imread("erode_source.png",0) # 读入灰度图片
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
# kernel指腐蚀操作的内核，可以利用getStructuringElement函数指明它的形状
res = cv2.erode(img,kernel,iterations=2)
# 处理结果=cv2.erode(原始图像src,卷积核kernel,迭代次数iterations)
cv2.imwrite("erode_dest02.png", res)

# 图像膨胀 黑色色区域减小，白色区域增大
img = cv2.imread("dilate_source.png",0) # 读入灰度图片
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
# 卷积核 正方形数组
res = cv2.dilate(img,kernel,iterations=2)
# 结果=cv2.dilate(二值图像src,卷积核k,迭代次数itreations)
cv2.imwrite("dilate_dest02.png", res)
