# -*- coding: utf-8 -*-
"""
nam:

fun:
    sklearn实现鸢尾花数据分类模型训练测试评估指标metrics
    使用http服务接口上传文件发送预测结果results
env:

ref:
    https://www.pianshen.com/article/3086301452/
"""
import numpy as np
import json

def train_fun(data_path, model_dir, result_img_dir, id):
    import os
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import joblib
    from sklearn.datasets import load_iris
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler, LabelEncoder, label_binarize
    from sklearn.multiclass import OneVsRestClassifier  # 一对其余（每次将一个类作为正类，剩下的类作为负类）
    from sklearn.linear_model import LogisticRegression
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.svm import SVC
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score, roc_curve, \
        roc_auc_score, classification_report, precision_recall_curve, average_precision_score,roc_curve, auc
    from scipy import interp
    from itertools import cycle

    if not os.path.exists(data_path) :
        raise ValueError(data_path,"not exist !")
    if not os.path.exists(model_dir) :
        os.makedirs(model_dir)
    if not os.path.exists(result_img_dir) :
        os.makedirs(result_img_dir)
    # Download the dataset and split into training and test data.
    # iris = load_iris()
    # print("iris.DESCR",iris.DESCR)
    # X = iris.data
    # y = iris.target
    # print("X.shape",X.shape)
    # print("X\n",X)
    # print("y.shape",y.shape)
    # print("y\n",y)
    # target_names=iris.target_names
    # n_classes=target_names.shape[0]     #多少类

    # 加载本地数据
    iris = pd.read_csv(data_path, usecols=[1, 2, 3, 4, 5])  # data_path = 'iris.csv'
    # iris.info()
    # print("iris.head\n",iris.head())
    # print("iris.describe\n",iris.describe())
    # 载入特征和标签集
    X = iris[['SepalLengthCm', 'SepalWidthCm', 'PetalLengthCm', 'PetalWidthCm']]
    y = iris['Species']
    target_names = iris['Species'].unique()
    n_classes = target_names.shape[0]  # 多少类

    # 对标签集进行编码
    encoder = LabelEncoder()
    y = encoder.fit_transform(y)
    # print("y\n",y)

    # Normalize the data so that the values all fall between 0 and 1.
    train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.3, random_state=0)
    print("train_X.shape:", train_X.shape, "train_y.shape:", train_y.shape, "test_X.shape:", test_X.shape,
          "test_y.shape:", test_y.shape)

    # 标准化特征值
    sc = StandardScaler()
    sc.fit(train_X)
    train_X_std = sc.transform(train_X)
    test_X_std = sc.transform(test_X)

    # Define the model
    # 模型创建训练保存
    # Decision Tree
    print("Decision Tree")
    clf = DecisionTreeClassifier()
    clf.fit(train_X_std, train_y)
    joblib.dump(clf, os.path.join(model_dir, "Tree.m"))  # 保存模型 model_dir
    score = clf.score(test_X_std, test_y)
    print("score", round(score, 3))  # accuracy_score

    # Evaluate the model and print the results
    print("Feature importances:\n{}".format(clf.feature_importances_))
    plt.figure()
    n_features = X.shape[1]  # iris.data.shape[1]
    plt.barh(range(n_features), clf.feature_importances_, align='center')
    plt.yticks(np.arange(n_features), X.columns.values, fontsize=5, rotation=45)
    # 指标显示不全，对坐标的大小方向设定 iris.feature_names
    plt.xlabel("Feature importance")
    plt.ylabel("Feature")
    plt.title('Feature Importance')
    img_fi_path = os.path.join(result_img_dir, "img_feature_importance_iris.png")
    plt.savefig(img_fi_path)  # 保存图片
    # plt.show()
    # del clf
    # 预测推理
    pred_y = clf.predict(test_X_std)
    # print("pred_y\n",pred_y)
    pred_y_proba = clf.predict_proba(test_X_std)
    # print("pred_y_proba\n",pred_y_proba)
    # 指标评估
    # print("classification_report\n",classification_report(test_y,pred_y,target_names=target_names))
    print("confusion_matrix\n", confusion_matrix(test_y, pred_y, labels=range(n_classes)))  #
    # 准确率
    metric_accuracy = accuracy_score(test_y, pred_y)
    print("metric_accuracy", round(metric_accuracy, 3))
    # 精准率
    metric_precision = precision_score(test_y, pred_y, average='macro')
    # 'micro':通过先计算总体的TP，FN和FP的数量，再计算F1 'macro':分布计算每个类别的F1，然后做平均（各类别F1的权重相同）
    print("metric_precision", round(metric_precision, 3))
    # 召回率
    metric_recall = recall_score(test_y, pred_y, average='macro')
    print("metric_recall", round(metric_recall, 3))
    # F1(精准率与召回率的平衡)
    metric_f1 = f1_score(test_y, pred_y, average='macro')
    print("metric_f1", round(metric_f1, 3))

    # 标签二值化,将三个类转为001, 010, 100的格式.因为这是个多类分类问题，后面将要采用
    # OneVsRestClassifier策略转为二类分类问题
    y = label_binarize(y, classes=[0, 1, 2])  # 将150*1转化成150*3
    n_classes = y.shape[1]  # 列的个数，等于3
    # print("y\n",y)

    # 训练集和测试集拆分
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

    # 一对其余，转换成两类，构建新的分类器
    clf = OneVsRestClassifier(SVC(kernel='linear', probability=True, random_state=0))
    # 训练集送给fit函数进行拟合训练，训练完后将测试集的样本特征注入，得到测试集中每个样本预测的分数
    clf.fit(X_train, y_train)
    # y_score = clf.decision_function(X_test)
    y_score = clf.predict(X_test)

    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    ################Compute micro-average ROC and ROC area##################################
    # 'micro':通过先计算总体的TP，FN和FP的数量，再计算
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    ################Compute macro-average ROC and ROC area##################################
    # 'macro':分布计算每个类别的指标，然后做指标平均
    # Compute ROC curve and ROC area for each class
    for i in range(n_classes):
        # 取出来的是各个类的测试值和预测值
        fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    # First aggregate all false positive rates
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    # Then interpolate all ROC curves at this points
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += interp(all_fpr, fpr[i], tpr[i])
    # Finally average it and compute AUC
    mean_tpr /= n_classes
    fpr["macro"] = all_fpr
    tpr["macro"] = mean_tpr
    roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
    ################Plot all ROC curves##################################################
    plt.figure()
    plt.plot(fpr["micro"], tpr["micro"],
             label='micro-average ROC curve (area/microAUC = {0:0.2f})'
                   ''.format(roc_auc["micro"]),
             color='deeppink', linestyle='solid', linewidth=2)
    plt.plot(fpr["macro"], tpr["macro"],
             label='macro-average ROC curve (area/macroAUC = {0:0.2f})'
                   ''.format(roc_auc["macro"]),
             color='navy', linestyle='solid', linewidth=2)
    colors = cycle(['aqua', 'darkorange', 'cornflowerblue'])
    for i, color in zip(range(n_classes), colors):
        plt.plot(fpr[i], tpr[i], color=color, linestyle='dotted', linewidth=2,
                 label='ROC curve of class {0} (area/AUC = {1:0.2f})'
                       ''.format(i, roc_auc[i]))
    # plt.plot([0, 1], [0, 1], 'k--', lw=lw)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC curve')
    plt.legend(loc="lower right")
    img_roc_path = os.path.join(result_img_dir,"img_ROC_iris.png")
    plt.savefig(img_roc_path)  # 保存图片
    # plt.show()

    precision = dict()
    recall = dict()
    average_precision = dict()
    ################Compute micro-average PR and PR area##################################
    # 'micro':通过先计算总体的TP，FN和FP的数量，再计算
    # Compute micro-average curve and area. ravel()将多维数组降为一维
    precision["micro"], recall["micro"], _ = precision_recall_curve(y_test.ravel(), y_score.ravel())
    average_precision["micro"] = average_precision_score(y_test, y_score,
                                                         average="micro")  # This score corresponds to the area under the precision-recall curve.
    ################Compute macro-average PR and PR area##################################
    # 'macro':分布计算每个类别的指标，然后做指标平均
    for i in range(n_classes):
        # 对于每一类，计算精确率和召回率的序列（:表示所有行，i表示第i列）
        precision[i], recall[i], _ = precision_recall_curve(y_test[:, i], y_score[:, i])
        average_precision[i] = average_precision_score(y_test[:, i], y_score[:, i])  # 切片，第i个类的分类结果性能
    # precision["macro"], recall["macro"], _ = precision_recall_curve(y_test,  y_score)
    average_precision["macro"] = average_precision_score(y_test, y_score, average="macro")
    ################Plot all PR curves##################################################
    plt.figure()
    plt.plot(recall["micro"], precision["micro"],
             label='micro-average PR curve (area/microAP = {0:0.2f})'
                   ''.format(average_precision["micro"]),
             color='deeppink', linestyle='solid', linewidth=2)
    # plt.plot(recall["macro"], precision["macro"],
    #          label='macro-average PR curve (area/macroAP = {0:0.2f})'
    #                ''.format(average_precision["macro"]),
    #          color='navy', linestyle='solid', linewidth=2)
    # Plot Precision-Recall curve for each class
    colors = cycle(['aqua', 'darkorange', 'cornflowerblue'])
    for i, color in zip(range(n_classes), colors):
        plt.plot(recall[i], precision[i], color=color, linestyle='dotted', linewidth=2,
                 label='PR curve of class {0} (area/AP = {1:0.2f})'
                       ''.format(i, average_precision[i]))
    # plt.plot([0, 1], [0, 1], 'k--', lw=lw)

    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])  # xlim、ylim：分别设置X、Y轴的显示范围。
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall curve')
    plt.legend(loc="lower left")  # legend 是用于设置图例的函数
    img_pr_path = os.path.join(result_img_dir, "img_PR_iris.png")
    plt.savefig(img_pr_path)  # 保存图片
    # plt.show()

    res_dict = {
        "accuracy": str(round(metric_accuracy,3)),
        "featureImportanceIndex": img_fi_path,
        "id": id,
        "mapIndicator": "mapIndicator",
        "name": os.path.split(__file__)[-1].split(".")[0] + "_pid" + str(os.getpid()), #"name",
        "prCurve": img_pr_path,
        "precise": str(round(metric_precision,3)),
        "recallRate": str(round(metric_recall,3)),
        "rocCurve": img_roc_path,
        "runName": "string",
        "totalTestSamples": str(test_X.shape[0]),
        "totalTrainingSamples": str(train_X.shape[0]),
        "user": "user"
    }
    return res_dict

def clent_post(url, send_dict):
    # 先发送图片clent post得到图片存储url地址，重载send_dict，再发送clent post
    import requests
    import json
    # 用户上传文件到默认的桶
    respon01 = requests.post(url=url + "/tabFile/uploadToDefaultBucketByUserId",
                             # headers={
                                 # "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                                 # "Accept-Encoding": "gzip, deflate",
                                 # "Accept-Language": "zh-CN,zh;q=0.9",
                                 # "Cache-Control": "max-age=0",
                                 # "Connection": "keep-alive",
                                 ## "Content-Type": "multipart/form-data",
                                 ## "Upgrade-Insecure-Requests": "1",
                                 # "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36"
                             # },
                             files={"files": open(send_dict["rocCurve"], "rb"),
                                    # "Content-Type": "application/octet-stream",
                                    # "Content-Disposition": "form-data"
                                    },
                             data= {"userId": "fengyouwei105@ebupt.com"}
                             )
    if respon01.status_code != 200: raise ValueError("status_code", status_code)
    # print(type(json.loads(respon01.text)["data"].values())) # <class 'dict_values'>
    # print(list(json.loads(respon01.text)["data"].values())[0]) # http://ceph.ai.ebiot.net:7480/eb-aipoc-userfengyouwei105ebupt-0-210206221933/img_ROC_iris-20210220204228.png
    send_dict["rocCurve"] = list(json.loads(respon01.text)["data"].values())[0]

    respon02 = requests.post(url=url + "/tabFile/uploadToDefaultBucketByUserId",
                             files={"files": open(send_dict["prCurve"], "rb")},
                             data={"userId": "fengyouwei105@ebupt.com"})
    if respon02.status_code != 200: raise ValueError("status_code", status_code)
    send_dict["prCurve"] = list(json.loads(respon02.text)["data"].values())[0]
    respon03 = requests.post(url=url + "/tabFile/uploadToDefaultBucketByUserId",
                             files={"files": open(send_dict["featureImportanceIndex"], "rb")},
                             data={"userId": "fengyouwei105@ebupt.com"})
    if respon03.status_code != 200: raise ValueError("status_code", status_code)
    send_dict["featureImportanceIndex"] = list(json.loads(respon03.text)["data"].values())[0]
    # API - 离线模型管理OfflineModelController 新增数据
    # send_dict = {
    #               "accuracy": "string",
    #               "featureImportanceIndex": "string",
    #               "id": 0,
    #               "mapIndicator": "string",
    #               "name": "string",
    #               "prCurve": "string",
    #               "precise": "string",
    #               "recallRate": "string",
    #               "rocCurve": "string",
    #               "runName": "string",
    #               "totalTestSamples": "string",
    #               "totalTrainingSamples": "string",
    #               "user": "string"
    #             }
    send_json = json.dumps(send_dict)
    respon = requests.post(url=url+"/offlineModel/addOfflineModel", data=send_json, headers={'Content-Type':'application/json'})
    if respon.status_code != 200: raise ValueError("status_code", status_code)
    respon_text_dict = json.loads(respon.text)
    return respon_text_dict

if __name__ == "__main__":
    data_path = "datasets/iris.csv"
    model_dir = "models"
    result_img_dir = "results"
    id = 0
    res_dict = train_fun(data_path, model_dir, result_img_dir, id)
    url = "http://10.1.60.103:8091" # http://10.4.6.229:8097  http://10.1.60.103:8091
    respon = clent_post(url, res_dict)
    print("respon\n",respon)