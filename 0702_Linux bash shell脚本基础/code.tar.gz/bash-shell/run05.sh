#/bin/bash
date "+%Y-%m-%d %H:%M:%S" >> log
date "+%Y-%m-%d %H:%M:%S" >> log
