# -*- coding: utf-8 -*-
'''
    查找所有图片
fun:
    遍历文件下所有图片并拷贝
ref:
    https://www.cnblogs.com/bigtreei/p/10683537.html
    https://blog.csdn.net/z772330927/article/details/103683461
'''
import os
import sys
# sys.setdefaultencoding("utf-8")
# print(sys.getdefaultencoding())  # utf-8
import shutil
import time
from tqdm import tqdm

def get_all_imgs_path(imgs_dir):
    img_list = []
    for fpathe, dirs, fs in os.walk(imgs_dir):
        for f in fs:
            if (f.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff'))):
                # print("img : ",f)
                img_path = os.path.join(fpathe, f)
                img_list.append(img_path)
    return img_list

def find_imgs_cp(imgs_dir, keywords, outdir) :
    img_list = get_all_imgs_path(imgs_dir)
    result_list = []
    print("查找的图片库图片数量为{}".format(len(img_list)))
    # print("img_list", img_list)
    for img_path in tqdm(img_list):
            if keywords in os.path.basename(img_path) :
                # print("img_path",img_path)
                save_path = os.path.join(outdir,os.path.basename(img_path))
                shutil.copyfile(img_path, save_path)
                result_list.append(img_path)
    return result_list

if __name__ == "__main__":
    outdir = "results"
    if os.path.exists(outdir):
        shutil.rmtree(outdir)
    os.makedirs(outdir)
    # imgs_dir = "imgs"
    imgs_dir = input("请输入图片库路径：") # /home/iot1/sfz/datasets/ocr/carplates
    print("你输入的图片库路径是: ", imgs_dir)
    if not os.path.exists(imgs_dir) : raise ValueError(imgs_dir,"not exist !")
    keywords = input("请输入图片中文字的关键字词（提示：图片中两个字间距不可过大，输入完后回车确认）：")
    print("你输入的内容是: ", keywords)
    start_time = time.time()
    result_list = find_imgs_cp(imgs_dir, keywords, outdir)
    print("找到了{}张相关图片".format(len(result_list)))
    print("相关的图片原地址为{}".format(result_list))
    end_time = time.time()
    print("用时{:.3f}秒".format(end_time-start_time))
