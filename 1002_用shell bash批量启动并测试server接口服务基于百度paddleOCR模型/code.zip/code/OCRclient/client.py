# coding: UTF-8
import requests
import json
import base64
import os
import time
import numpy as np
import cv2

def getImg(image_path,image_name):
    #注意修改serverIP的地址
    serverIP = 'http://10.1.68.151:8080/generalOcr'#通用文字识别
    # serverIP = 'http://10.1.68.151:8080/logoOcr'
    imageData = base64.b64encode(open(image_path,'rb').read()).decode()
    further_data ={}
    further_data['image_data'] = imageData
    further_data['image_name'] = image_name
    data = json.dumps(further_data)
    r = requests.post(url=serverIP, data=data, headers={'Content-Type':'application/json'})
    res = json.loads(r.text)
    return res


if __name__ == "__main__":
    path = './images/generalOcr/'#注意修改图片路径
    # path = './images/logoOcr/'
    for i in range(0,50):
        for filename in os.listdir(path):
            t1 = time.time()
            print("filename: ",filename)
            image_path = path + filename
            res = getImg(image_path,filename)
            print("res: ",res)
