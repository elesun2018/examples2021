#!/bin/bash
echo -e "visiting generalOcr"
(echo -n '{"image_data": "';
base64 images/generalOcr/0001.jpg;
echo '","image_name" : "0001.jpg"}') |
curl -H "Content-Type: application/json" -d @-  http://10.1.68.151:8080/generalOcr

echo -e "\nvisiting logoOcr"
(echo -n '{"image_data": "';
base64 images/logoOcr/361_0_00011.jpg;
echo '","image_name" : "361_0_00011.jpg"}') |
curl -H "Content-Type: application/json" -d @-  http://10.1.68.151:8080/logoOcr



