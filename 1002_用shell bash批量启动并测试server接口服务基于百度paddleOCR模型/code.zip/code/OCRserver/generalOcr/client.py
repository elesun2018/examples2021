# -*- coding: utf-8 -*-
"""
http请求 clent端
"""
import base64
import json
import os

import requests


def clent_post(url, image_path):
    send_dict ={}
    send_dict['image_name'] = os.path.basename(image_path)
    imageData = base64.b64encode(open(image_path,'rb').read()).decode()
    send_dict['image_data'] = imageData
    send_json = json.dumps(send_dict)
    respon = requests.post(url=url, data=send_json, headers={'Content-Type':'application/json'})
    res = json.loads(respon.text)
    return res

if __name__ == "__main__":
    url = "http://127.0.0.1:8083/generalOcr"
    image_path = "imgs/IMG_20210813_154135.jpg" # IMG_20210813_154135.jpg IMG_20210813_154249.jpg notext.png
    res_dict = clent_post(url, image_path)
    # 获取响应字典字段
    # print("res_dict: ",res_dict)
    print("result_code",res_dict["result_code"])
    print("result_data",res_dict["result_data"])
    print("clent response end !")
