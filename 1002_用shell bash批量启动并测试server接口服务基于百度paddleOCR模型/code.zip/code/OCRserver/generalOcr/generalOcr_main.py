# -*- coding: utf-8 -*-
"""
Flask Web微框架 服务器端server
"""
import base64
import json
import time

import cv2
from infer import save_structure_res,OCRSystem
import numpy as np
from flask import Flask, request
import os
from utility import parse_args


args = parse_args()
args.det_model_dir = "inference/ch_ppocr_mobile_v2.0_det_infer"
args.rec_model_dir = "inference/ch_ppocr_mobile_v2.0_rec_infer"
args.table_model_dir = "inference/en_ppocr_mobile_v2.0_table_structure_infer"
args.rec_char_dict_path = "ppocr/utils/ppocr_keys_v1.txt"
args.table_char_dict_path = "ppocr/utils/dict/table_structure_dict.txt"
args.rec_char_type = "ch"
args.output = "output"
args.vis_font_path = "fonts/simfang.ttf"

save_folder = args.output
os.makedirs(save_folder, exist_ok=True)

structure_sys = OCRSystem(args)

app = Flask(__name__)


os.system('touch c.log')
@app.route('/generalOcr', methods=['POST'])
def server_response():
    start_time = time.time()
    results_dict = {}
    try:
        image_name = request.json['image_name']
        image_data = request.json['image_data']
        img_b64 = base64.b64decode(image_data)
        buff2np = np.frombuffer(img_b64, np.uint8)
        img_dec = cv2.imdecode(buff2np, cv2.IMREAD_COLOR)
        sp = img_dec.shape
    except:
        results_dict["result_code"] = 202  # 识别失败，图片格式错误
        results_dict["result_data"] = {}
        results_json = json.dumps(results_dict)
        return results_json
    try:
        # res_dict = infer.infer_imgdata(image_name, img_dec)
        res = structure_sys(img_dec, image_name)
        res_dict = save_structure_res(res, save_folder, image_name)
    # print("res_dict",res_dict)
    except:
        results_dict["result_code"] = 203  # 识别失败，其他错误
        results_dict["result_data"] = {}
        results_json = json.dumps(results_dict)
        return results_json
    try:
        assert len(res_dict["value"]) > 0
    except:
        results_dict["result_code"] = 201  # 识别失败，图片中没有文本
        results_dict["result_data"] = {}
        results_json = json.dumps(results_dict)
        return results_json
    results_dict["result_code"] = 200  # 识别成功
    results_dict["result_data"] = res_dict
    results_json = json.dumps(results_dict)  # 将结果填入json文件中并返回结果
    return results_json


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8083)

