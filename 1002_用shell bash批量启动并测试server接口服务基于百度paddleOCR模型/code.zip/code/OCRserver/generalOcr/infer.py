import os
import sys

__dir__ = os.path.dirname(os.path.abspath(__file__))
sys.path.append(__dir__)
sys.path.append(os.path.abspath(os.path.join(__dir__, '..')))

os.environ["FLAGS_allocator_strategy"] = 'auto_growth'
import cv2
import numpy as np
import time
import logging

from ppocr.utils.utility import get_image_file_list, check_and_read_gif
from ppocr.utils.logging import get_logger
from tools.infer.predict_system import TextSystem
from table.predict_table import TableSystem
from utility import parse_args, draw_structure_result

logger = get_logger()


class OCRSystem(object):
    def __init__(self, args):
        import layoutparser as lp
        # args.det_limit_type = 'resize_long'
        args.drop_score = 0
        if not args.show_log:
            logger.setLevel(logging.INFO)
        self.text_system = TextSystem(args)
        self.table_system = TableSystem(args, self.text_system.text_detector, self.text_system.text_recognizer)

        config_path = None
        model_path = None
        if os.path.isdir(args.layout_path_model):
            model_path = args.layout_path_model
        else:
            config_path = args.layout_path_model
        self.table_layout = lp.PaddleDetectionLayoutModel(config_path=config_path,
                                                          model_path=model_path,
                                                          threshold=0.5, enable_mkldnn=args.enable_mkldnn,
                                                          enforce_cpu=args.use_gpu, thread_num=args.cpu_threads)
        print("args.use_gpu: ", args.use_gpu)
        self.use_angle_cls = args.use_angle_cls
        self.drop_score = args.drop_score

    def __call__(self, img, img_name):
        ori_im = img.copy()
        layout_res = self.table_layout.detect(img[..., ::-1])
        print("layout_res: ", layout_res)
        res_list = []
        num = 0
        for region in layout_res:
            x1, y1, x2, y2 = region.coordinates
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
            roi_img = ori_im[y1:y2, x1:x2, :]
            # print("img_name: ",img_name)
            # cv2.imwrite("./out/"+str(num)+"_"+img_name+".png",roi_img)
            num = num + 1
            if region.type == '1':  # Table
                res = self.table_system(roi_img)
                print("****************************************************")
            else:
                filter_boxes, filter_rec_res = self.text_system(roi_img)
                # print("filter_rec_res: ",filter_rec_res)
                # print("filter_boxes: ",filter_boxes)
                filter_boxes = [x + [x1, y1] for x in filter_boxes]
                filter_boxes = [x.reshape(-1).tolist() for x in filter_boxes]
                # remove style char
                style_token = ['<strike>', '<strike>', '<sup>', '</sub>', '<b>', '</b>', '<sub>', '</sup>',
                               '<overline>', '</overline>', '<underline>', '</underline>', '<i>', '</i>']
                filter_rec_res_tmp = []
                for rec_res in filter_rec_res:
                    rec_str, rec_conf = rec_res
                    for token in style_token:
                        if token in rec_str:
                            rec_str = rec_str.replace(token, '')
                    filter_rec_res_tmp.append((rec_str, rec_conf))
                res = (filter_boxes, filter_rec_res_tmp)
            res_list.append({'type': region.type, 'bbox': [x1, y1, x2, y2], 'img': roi_img, 'res': res})
        return res_list


def save_structure_res(res, save_folder, img_name):
    excel_save_folder = os.path.join(save_folder, img_name)
    os.makedirs(excel_save_folder, exist_ok=True)
    res_dict = {}
    value_list = []
    # save res
    with open(os.path.join(excel_save_folder, 'res.txt'), 'w', encoding='utf8') as f:
        for region in res:
            # if region['type'] == 'Table':
            #    excel_path = os.path.join(excel_save_folder, '{}.xlsx'.format(region['bbox']))
            #    to_excel(region['res'], excel_path)
            # if region['type'] == 'Figure':
            raw_img = region['img']
            img_path = os.path.join(excel_save_folder, '{}.jpg'.format(img_name))
            cv2.imwrite(img_path, raw_img)
            if len(region['res'][0]) > 0:
                for box, rec_res in zip(region['res'][0], region['res'][1]):
                    f.write('text:{}\t,box:{}\n'.format(rec_res, np.array(box).reshape(-1).tolist()))
                    box_dict = {"text": rec_res[0], "box": np.array(box).reshape(-1).tolist()}
                    value_list.append(box_dict)
            else:
                f.write("no txt detected !")
            # else:
            #    for box, rec_res in zip(region['res'][0], region['res'][1]):
            #        f.write('{}\t{}\n'.format(np.array(box).reshape(-1).tolist(), rec_res))
    res_dict["image_name"] = img_name
    res_dict["value"] = value_list
    return res_dict


def infer(image_dir):
    args.image_dir = image_dir  # "imgs"
    args.det_model_dir = "inference/ch_ppocr_mobile_v2.0_det_infer"
    args.rec_model_dir = "inference/ch_ppocr_mobile_v2.0_rec_infer"
    args.table_model_dir = "inference/en_ppocr_mobile_v2.0_table_structure_infer"
    args.rec_char_dict_path = "ppocr/utils/ppocr_keys_v1.txt"
    args.table_char_dict_path = "ppocr/utils/dict/table_structure_dict.txt"
    args.rec_char_type = "ch"
    args.output = "output"
    args.vis_font_path = "fonts/simfang.ttf"

    image_file_list = get_image_file_list(args.image_dir)
    image_file_list = image_file_list
    image_file_list = image_file_list[args.process_id::args.total_process_num]
    save_folder = args.output
    os.makedirs(save_folder, exist_ok=True)

    structure_sys = OCRSystem(args)
    img_num = len(image_file_list)
    for i, image_file in enumerate(image_file_list):
        logger.info("[{}/{}] {}".format(i, img_num, image_file))
        img, flag = check_and_read_gif(image_file)
        img_name = os.path.basename(image_file).split('.')[0]

        if not flag:
            img = cv2.imread(image_file)
        if img is None:
            logger.error("error in loading image:{}".format(image_file))
            continue
        starttime = time.time()
        res = structure_sys(img, img_name)
        res_dict = save_structure_res(res, save_folder, img_name)
        print("res_dict\n", res_dict)
        draw_img = draw_structure_result(img, res, args.vis_font_path)
        cv2.imwrite(os.path.join(save_folder, img_name, 'show.jpg'), draw_img)
        logger.info('result save to {}'.format(os.path.join(save_folder, img_name)))
        elapse = time.time() - starttime
        logger.info("Predict time : {:.3f}s".format(elapse))


def infer_imgdata(image_name, img_dec):
    args.det_model_dir = "inference/ch_ppocr_mobile_v2.0_det_infer"
    args.rec_model_dir = "inference/ch_ppocr_mobile_v2.0_rec_infer"
    args.table_model_dir = "inference/en_ppocr_mobile_v2.0_table_structure_infer"
    args.rec_char_dict_path = "ppocr/utils/ppocr_keys_v1.txt"
    args.table_char_dict_path = "ppocr/utils/dict/table_structure_dict.txt"
    args.rec_char_type = "ch"
    args.output = "output"
    args.vis_font_path = "fonts/simfang.ttf"

    save_folder = args.output
    os.makedirs(save_folder, exist_ok=True)

    structure_sys = OCRSystem(args)

    starttime = time.time()
    res = structure_sys(img_dec, image_name)
    res_dict = save_structure_res(res, save_folder, image_name)
    print("res_dict\n", res_dict)
    # draw_img = draw_structure_result(img, res, args.vis_font_path)
    # cv2.imwrite(os.path.join(save_folder, img_name, 'show.jpg'), draw_img)
    # logger.info('result save to {}'.format(os.path.join(save_folder, img_name)))
    elapse = time.time() - starttime
    logger.info("Predict time : {:.3f}s".format(elapse))
    return res_dict


args = parse_args()
print("*********************************************")
print("args: ", args)
print("**********************************************")
if __name__ == "__main__":
    image_dir = "imgs"
    infer(image_dir)
