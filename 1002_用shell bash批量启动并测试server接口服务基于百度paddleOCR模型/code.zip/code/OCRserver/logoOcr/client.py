"""
http请求 clent端
"""
import base64
import json
import os

import requests


def clent_post(url, image_path):
    send_dict = {}
    send_dict['image_name'] = os.path.basename(image_path)
    imageData = base64.b64encode(open(image_path, 'rb').read()).decode()
    send_dict['image_data'] = imageData
    send_json = json.dumps(send_dict)
    respon = requests.post(url=url, data=send_json, headers={'Content-Type': 'application/json'})
    res = json.loads(respon.text)
    return res


if __name__ == "__main__":
    url = "http://127.0.0.1:8086/logoOcr"
    image_path = "imgs/test.jpg" # 00001647  00001649  00001652
    res_dict = clent_post(url, image_path)
    print("res_dict", res_dict)
    print("clent response end !")
