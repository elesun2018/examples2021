#!/bin/bash/python

nohup python -u thread.py >log 2>&1 &
rm -f generalOcr/c.log
echo 'The generalOcr service is starting, Please wait a moment!'
cd generalOcr && nohup python -u generalOcr_main.py >log 2>&1 &
while :
do
	if [ -f "generalOcr/c.log" ]
	then
		echo 'Start-up success'
		rm -f generalOcr/c.log
		break
	fi
done

rm -f logoOcr/f.log
echo 'The logoOcr service is starting, Please wait a moment!'
cd logoOcr && nohup python -u logoOcr_main.py >log 2>&1 &
while :
do
  if [ -f "logoOcr/f.log" ]
  then
    echo 'Start-up success'
    rm -f logoOcr/f.log
    break
  fi
done

while :
do
sleep 60
done
exit
