# coding:UTF-8
from gevent import monkey
from gevent.pywsgi import WSGIServer
#from geventwebsocket.handler import WebSocketHandler

from PIL import Image
import os
import sys
from flask import Flask,request


import json
import base64
import numpy as np
import cv2
import time
import requests
import json

monkey.patch_all()
app = Flask(__name__)

app.config.update(
    DEBUG=False
)

class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, bytes):
            return str(obj, encoding='utf-8')
        return json.JSONEncoder.default(self, obj)

@app.route('/generalOcr', methods=['POST'])
def generalOcr():
    image_data = request.json['image_data']
    image_name = request.json['image_name']
    rest = {}
    rest['image_data'] = image_data
    rest['image_name'] = image_name
    data = json.dumps(rest, cls=MyEncoder)
    r = requests.post(url='http://0.0.0.0:8083/generalOcr', data=data, headers={'Content-Type':'application/json'})
    return r.text

@app.route('/logoOcr', methods=['POST'])
def logoOcr():
    image_data = request.json['image_data']
    image_name = request.json['image_name']
    rest = {}
    rest['image_data'] = image_data
    rest['image_name'] = image_name
    data = json.dumps(rest, cls=MyEncoder)
    r = requests.post(url='http://0.0.0.0:8086/logoOcr', data=data, headers={'Content-Type':'application/json'})
    return r.text

if __name__ == '__main__':
    http_server = WSGIServer(('0.0.0.0', 8080), app)
    http_server.serve_forever()

