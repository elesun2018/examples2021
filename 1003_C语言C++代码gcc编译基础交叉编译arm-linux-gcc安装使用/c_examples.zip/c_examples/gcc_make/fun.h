#ifndef _FUN_H
#define _FUN_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern void function(unsigned char cnt);

#endif

