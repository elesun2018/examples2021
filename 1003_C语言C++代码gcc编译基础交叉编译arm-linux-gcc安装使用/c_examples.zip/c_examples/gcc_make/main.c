#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fun.h"

unsigned char n;

int main(void)
{
	n = 50;
	function(n);
	return(0);
}
