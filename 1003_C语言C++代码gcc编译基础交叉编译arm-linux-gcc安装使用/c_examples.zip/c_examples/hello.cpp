#include "iostream"
// Sample C++ prgoram
int main(void)
{
std::cout << "Hello! This is a C++ program.\n";
return 0;
}