#include <stdio.h>
#include "test_so.h"
 
void test_a()
{
    printf("%s, %d\n", __func__, __LINE__);
}