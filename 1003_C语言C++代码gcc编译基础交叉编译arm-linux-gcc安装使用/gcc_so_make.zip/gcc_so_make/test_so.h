#ifndef TEST_SO_H
#define TEST_SO_H
 
void test_a();
void test_b();
 
#endif