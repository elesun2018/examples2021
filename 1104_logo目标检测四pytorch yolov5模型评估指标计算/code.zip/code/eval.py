# -*- coding: utf-8 -*-
"""
   voc-obj-eval-torch
"""
import os
import warnings
warnings.filterwarnings("ignore")
import shutil
import torch
import infer
import metrics

if __name__ == "__main__":
    #################################GPU config#############################################
    print("#" * 30, "GPU config", "#" * 30)
    print("torch version :", torch.__version__)
    print("cuda version :", torch.version.cuda)
    # os.environ["CUDA_VISIBLE_DEVICES"] = "1"  # elesun
    print("GPU available :", torch.cuda.is_available())
    print("GPU count :", torch.cuda.device_count())
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # cuda cuda:0 cuda:1 cpu
    print("GPU current :", torch.cuda.current_device(), torch.cuda.get_device_name(torch.cuda.current_device()))
    print("device: ", device)
    #################################eval model#############################################
    models_dir = "model_loc"
    model_path = os.path.join(models_dir, [i for i in os.listdir(models_dir) if i.endswith(".pt")][-1])
    if not os.path.exists(model_path): raise ValueError(model_path, "not exist !")
    gt_dir = 'gt_voc_loc'
    print("#" * 30, "eval model", "#" * 30)
    print("[INFO] eval start ...")
    pd_dir = "pd_xml_voc"
    infer.model_infer(gt_dir, model_path, pd_dir, device)
    result_dir = "results"
    if os.path.exists(result_dir):
        shutil.rmtree(result_dir)
    os.makedirs(result_dir)
    res_dict = metrics.calculation(gt_dir, pd_dir, result_dir)
    print("res_dict", res_dict)