import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "1" # sun
import time
from lxml import etree
from models.yolo import Model
import numpy as np
import cv2
import torch
from numpy import random
import shutil
from utils.datasets import letterbox
from utils.general import check_img_size, check_requirements, check_imshow, non_max_suppression, apply_classifier, \
    scale_coords, xyxy2xywh, strip_optimizer, set_logging, increment_path
from utils.plots import plot_one_box

class GEN_Annotations:
    def __init__(self, filename):
        self.root = etree.Element("annotation")
        child1 = etree.SubElement(self.root, "folder")
        child1.text = "VOC2007"
        child2 = etree.SubElement(self.root, "filename")
        child2.text = filename
        child3 = etree.SubElement(self.root, "source")
        child4 = etree.SubElement(child3, "database")
        child4.text = "The PASCAL VOC2007 Database"
        child5 = etree.SubElement(child3, "annotation")
        child5.text = "PASCAL VOC2007"
        child6 = etree.SubElement(child3, "image")
        child6.text = "flickr"
        child7 = etree.SubElement(child3, "flickrid")
        child7.text = "69965"
        child8 = etree.SubElement(self.root, "owner")
        child9 = etree.SubElement(child8, "flickrid")
        child9.text = "sun"
        child10= etree.SubElement(child8, "name")
        child10.text = "sfz"
    def set_size(self,witdh,height,channel):
        size = etree.SubElement(self.root, "size")
        widthn = etree.SubElement(size, "width")
        widthn.text = str(witdh)
        heightn = etree.SubElement(size, "height")
        heightn.text = str(height)
        channeln = etree.SubElement(size, "depth")
        channeln.text = str(channel)
    def savefile(self,filename):
        tree = etree.ElementTree(self.root)
        tree.write(filename, pretty_print=True, xml_declaration=False, encoding='utf-8')
    def add_pic_attr(self,label,score,xmin,ymin,xmax,ymax):
        object = etree.SubElement(self.root, "object")
        namen = etree.SubElement(object, "name")
        namen.text = label
        pose = etree.SubElement(object, "score")
        pose.text = str(score)
        truncated = etree.SubElement(object, "truncated")
        truncated.text = str(0)
        difficult = etree.SubElement(object, "difficult")
        difficult.text = str(0)
        bndbox = etree.SubElement(object, "bndbox")
        xminn = etree.SubElement(bndbox, "xmin")
        xminn.text = str(xmin)
        yminn = etree.SubElement(bndbox, "ymin")
        yminn.text = str(ymin)
        xmaxn = etree.SubElement(bndbox, "xmax")
        xmaxn.text = str(xmax)
        ymaxn = etree.SubElement(bndbox, "ymax")
        ymaxn.text = str(ymax)
    def genvoc(filename,class_,width,height,depth,xmin,ymin,xmax,ymax,savedir):
        anno = GEN_Annotations(filename)
        anno.set_size(width,height,depth)
        anno.add_pic_attr("pos", xmin, ymin, xmax, ymax)
        anno.savefile(savedir)

def model_infer(test_dir, model_path, result_dir, device):
    if os.path.exists(result_dir):
        shutil.rmtree(result_dir)
    os.makedirs(result_dir)
    #################################data process#############################################
    print("#" * 30, "data process", "#" * 15)
    name_classes = ['puma', 'adidas', 'kappa', '361', 'xtep', 'anta', 'lining', 'erke', 'nb', 'nike']
    img_lists = os.listdir(test_dir)
    img_lists = [i for i in img_lists if i.endswith(".jpg")]
    #################################model load#############################################
    print("#" * 30, "model load", "#" * 15)
    start_time = time.time()
    cfg_dict = {
        "nc": 3000,
        "depth_multiple": 0.33,  # model depth multiple
        "width_multiple": 0.50,  # layer channel multiple
        "anchors": [
            [10, 13, 16, 30, 33, 23],  # P3/8
            [30, 61, 62, 45, 59, 119],  # P4/16
            [116, 90, 156, 198, 373, 326]  # P5/32
        ],
        "backbone":  # [from, number, module, args]
            [[-1, 1, "Focus", [64, 3]],  # 0-P1/2
             [-1, 1, "Conv", [128, 3, 2]],  # 1-P2/4
             [-1, 3, "C3", [128]],
             [-1, 1, "Conv", [256, 3, 2]],  # 3-P3/8
             [-1, 9, "C3", [256]],
             [-1, 1, "Conv", [512, 3, 2]],  # 5-P4/16
             [-1, 9, "C3", [512]],
             [-1, 1, "Conv", [1024, 3, 2]],  # 7-P5/32
             [-1, 1, "SPP", [1024, [5, 9, 13]]],
             [-1, 3, "C3", [1024, False]],  # 9
             ],
        "head":
            [[-1, 1, "Conv", [512, 1, 1]],
             [-1, 1, "nn.Upsample", [None, 2, 'nearest']],
             [[-1, 6], 1, "Concat", [1]],  # cat backbone P4
             [-1, 3, "C3", [512, False]],  # 13

             [-1, 1, "Conv", [256, 1, 1]],
             [-1, 1, "nn.Upsample", [None, 2, 'nearest']],
             [[-1, 4], 1, "Concat", [1]],  # cat backbone P3
             [-1, 3, "C3", [256, False]],  # 17 (P3/8-small)

             [-1, 1, "Conv", [256, 3, 2]],
             [[-1, 14], 1, "Concat", [1]],  # cat head P4
             [-1, 3, "C3", [512, False]],  # 20 (P4/16-medium)

             [-1, 1, "Conv", [512, 3, 2]],
             [[-1, 10], 1, "Concat", [1]],  # cat head P5
             [-1, 3, "C3", [1024, False]],  # 23 (P5/32-large)

             [[17, 20, 23], 1, "Detect", ["nc", "anchors"]],  # Detect(P3, P4, P5)
             ]
    }
    model = Model(cfg_dict, ch=3, nc=10)
    ckpt = torch.load(model_path)
    state_dict = ckpt['model'].state_dict()
    model.load_state_dict(state_dict)
    model.to(device)
    model.eval()
    end_time = time.time()
    print("load model time use {:.3f} S".format(end_time - start_time))
    #################################model load#############################################
    print("#" * 30, "model infer", "#" * 15)
    start_time = time.time()
    colors = [[random.randint(0, 255) for _ in range(3)] for _ in name_classes]
    conf_thres = 0.25
    iou_thres = 0.45
    img_size = 640
    stride = 32
    with torch.no_grad():
        for img_name in img_lists:
            img_path = os.path.join(test_dir, img_name)
            if not os.path.exists(img_path):
                raise ValueError(img_path, "not exist !")
            anno = GEN_Annotations(img_name)
            img0 = cv2.imread(img_path)  # BGR
            print("img_path:", img_path)
            # anno.set_size(image.size[0], image.size[1], 3)
            anno.set_size(*img0.shape)
            # Padded resize
            img = letterbox(img0, img_size, stride=stride)[0]
            # Convert
            img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB, to 3x416x416
            img = np.ascontiguousarray(img)
            img = torch.from_numpy(img).to(device)
            img = img.float()  # uint8 to fp16/32
            img /= 255.0  # 0 - 255 to 0.0 - 1.0
            img = img.unsqueeze(0)
            pred = model(img)[0]
            # Apply NMS
            pred = non_max_suppression(pred, conf_thres, iou_thres)
            for i, det in enumerate(pred):  # detections per image
                save_img_path = os.path.join(result_dir, img_name)
                save_xml_path = os.path.join(result_dir, img_name.replace(".jpg", ".xml"))
                boxes_str = ''
                boxes_str += '%gx%g ' % img.shape[2:]  # print string
                if len(det):
                    # Rescale boxes from img_size to img0 size
                    det[:, :4] = scale_coords(img.shape[2:], det[:, :4], img0.shape).round()
                    # print("box len",len(det))
                    # Print results
                    for c in det[:, -1].unique():
                        n = (det[:, -1] == c).sum()  # detections per class
                        boxes_str += f"{n} {name_classes[int(c)]}{'s' * (n > 1)}, "  # add to string
                    print("boxes_str :",boxes_str)
                    # Write results
                    for *xyxy, conf, cls in reversed(det):
                        # Write to file
                        # xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                        # line = (cls, *xywh, conf)
                        # print("line",line) # (tensor(14., device='cuda:1'), 0.49531251192092896, 0.637499988079071, 0.776562511920929, 0.7250000238418579, tensor(0.54114, device='cuda:1'))
                        # Add bbox to image
                        tag = f'{name_classes[int(cls)]} {conf:.2f}'
                        plot_one_box(xyxy, img0, label=tag, color=colors[int(cls)], line_thickness=3)
                        # Add bbox to xml
                        label = name_classes[int(cls)]
                        score = float('%.3f' % conf)
                        xmin, ymin, xmax, ymax = int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3])
                        anno.add_pic_attr(label, score, xmin, ymin, xmax, ymax)  # label boxes
                cv2.imwrite(save_img_path, img0)
                anno.savefile(save_xml_path)  # "00001.xml"
    end_time = time.time()
    print("infer time use {:.3f} S".format(end_time - start_time))
    print("Results saved to",result_dir)

if __name__ == '__main__':
    #################################GPU config#############################################
    print("#" * 30, "GPU config", "#" * 30)
    print("torch version :", torch.__version__)
    print("cuda version :", torch.version.cuda)
    # os.environ["CUDA_VISIBLE_DEVICES"] = "1"  # elesun
    print("GPU available :", torch.cuda.is_available())
    print("GPU count :", torch.cuda.device_count())
    device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")  # cuda cuda:0 cuda:1 cpu
    print("GPU current :", torch.cuda.current_device(), torch.cuda.get_device_name(torch.cuda.current_device()))
    print("device: ", device)
    #################################model test#############################################
    print("#" * 30, "model test", "#" * 30)
    test_dir = 'gt_voc_loc'
    model_path = 'model_loc/sport-yolov5s-best.pt'
    result_dir = "results"
    model_infer(test_dir, model_path, result_dir, device)